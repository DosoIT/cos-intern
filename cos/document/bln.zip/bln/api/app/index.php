<?php

require '.././libs/Slim/Slim.php';
require_once 'dbHelper.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();
$app = \Slim\Slim::getInstance();
$db = new dbHelper();

/**
 * Database Helper Function templates
 */
/*
  select(table name, where clause as associative array)
  insert(table name, data as associative array, mandatory column names as array)
  update(table name, column names as associative array, where clause as associative array, required columns as array)
  delete(table name, where clause as array)
 */

//---------------------->new
$app->get('/list/all', function() {
    global $db;
    $rows = $db->select2('datastore', '*', array(), 'name asc');
    if ($rows["status"] == "success") {
        $rows["message"] = "select successfully.";
    }
    echoResponse(200, $rows);
});
$app->put('/update/regis/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $requiredColumnsArray = array();
    $rows2 = $db->update("datastore", $data, array('id' => $id), $requiredColumnsArray);
    if ($rows2["status"] == "success") {
        $rows2["message"] = "update successfully.";
        $rows2["session"] = 1;
    } else {
        $rows2["session"] = 1;
    }
    echoResponse(200, $rows2);
});
$app->put('/update/clear', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $requiredColumnsArray = array();
    $rows2 = $db->update("datastore", $data, array(), $requiredColumnsArray);
    if ($rows2["status"] == "success") {
        $rows2["message"] = "update successfully.";
        $rows2["session"] = 1;
    } else {
        $rows2["session"] = 1;
    }
    echoResponse(200, $rows2);
});
$app->put('/update/clear/fixed/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $requiredColumnsArray = array();
    $rows2 = $db->update("datastore", $data, array('id' => $id), $requiredColumnsArray);
    if ($rows2["status"] == "success") {
        $rows2["message"] = "update successfully.";
        $rows2["session"] = 1;
    } else {
        $rows2["session"] = 1;
    }
    echoResponse(200, $rows2);
});

function echoResponse($status_code, $response) {
    global $app;
    $app->status($status_code);
    $app->contentType('application/json');
//    echo json_encode($response, JSON_NUMERIC_CHECK);
    echo json_encode($response);
}

$app->run();
?>