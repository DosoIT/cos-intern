<?php

require '.././libs/Slim/Slim.php';
require_once 'dbHelper.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();
$app = \Slim\Slim::getInstance();
$db = new dbHelper();

/**
 * Database Helper Function templates
 */
/*
  select(table name, where clause as associative array)
  insert(table name, data as associative array, mandatory column names as array)
  update(table name, column names as associative array, where clause as associative array, required columns as array)
  delete(table name, where clause as array)
 */

$app->post('/create/knowledge', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array("detail");
            $rows2 = $db->insert("knowledge", $data, $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "added successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->post('/create/slide', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array("detail");
            $rows2 = $db->insert("slide", $data, $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "added successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->post('/create/product', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array("detail");
            $rows2 = $db->insert("product", $data, $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "added successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/product/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("product", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->delete('/delete/product/:id', function($id) {    
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->delete("product", array('id' => $id));
            if ($rows2["status"] == "success") {
                $rows2["message"] = "deleted successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->post('/create/personnel', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array("name");
            $rows2 = $db->insert("personnel", $data, $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "added successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->post('/create/news', function()use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array("detail");
            $rows2 = $db->insert("news", $data, $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "added successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->delete('/delete/knowledge/:id', function($id) {    
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->delete("knowledge", array('id' => $id));
            if ($rows2["status"] == "success") {
                $rows2["message"] = "deleted successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->delete('/delete/news/:id', function($id) {    
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->delete("news", array('id' => $id));
            if ($rows2["status"] == "success") {
                $rows2["message"] = "deleted successfully.";
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }else{
                $rows2["session"] = 1;
            }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->delete('/delete/slide/:id', function($id) {    
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->delete("slide", array('id' => $id));
            if ($rows2["status"] == "success") {
                $rows2["message"] = "deleted successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->delete('/delete/personnel/:id', function($id) {    
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->delete("personnel", array('id' => $id));
            if ($rows2["status"] == "success") {
                $rows2["message"] = "deleted successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/slide/num/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {            
            $rows2 = $db->update("slide", $data, array('id' => $id), array());
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/knowledge/cover/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("knowledge", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/news/cover/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("news", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});

$app->put('/update/knowledge/data/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("knowledge", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/news/data/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("news", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->put('/update/personnel/data/:id', function($id)use($app) {
    $data = json_decode($app->request->getBody());
    global $db;
    $cookie = "" . @$_COOKIE['remember_token'];
    $rows = $db->select("user", "count(*) as session", array("remember_token" => $cookie));
    if ($rows['status'] == "success") {
        if ($rows['data'][0]['session'] == 1) {
            $requiredColumnsArray = array();
            $rows2 = $db->update("personnel", $data, array('id' => $id), $requiredColumnsArray);
            if ($rows2["status"] == "success") {
                $rows2["message"] = "update successfully.";
                $rows2["session"] = 1;
            }else{
                $rows2["session"] = 1;
            }
            echoResponse(200, $rows2);
        }
    } else {
        $rows['message'] = "Not admin!";
        echoResponse(200, $rows);
    }
});
$app->get('/list/knowledge', function() {
    global $db;
    $rows = $db->select2('knowledge', '*', array(), 'ORDER BY id desc');
    if ($rows["status"] == "success") {
        $rows["message"] = "added successfully.";
    }
    echoResponse(200, $rows);
});
$app->get('/list/news', function() {
    global $db;
    $rows = $db->select2('news', '*', array(), 'ORDER BY id desc');
    if ($rows["status"] == "success") {
        $rows["message"] = "added successfully.";
    }
    echoResponse(200, $rows);
});
$app->get('/list/slide', function() {
    global $db;
    $rows = $db->select2('slide', '*', array(), 'ORDER BY num ASC');
    if ($rows["status"] == "success") {
        $rows["message"] = "added successfully.";
    }
    echoResponse(200, $rows);
});
$app->get('/list/personnel', function() {
    global $db;
    $rows = $db->select2('personnel', '*', array(), 'ORDER BY num ASC');
    if ($rows["status"] == "success") {
        $rows["message"] = "added successfully.";
    }
    echoResponse(200, $rows);
});
$app->get('/list/product', function() {
    global $db;
    $rows = $db->select2('product', '*', array(), 'ORDER BY id DESC');
    if ($rows["status"] == "success") {
        $rows["message"] = "added successfully.";
    }
    echoResponse(200, $rows);
});

function echoResponse($status_code, $response) {
    global $app;
    $app->status($status_code);
    $app->contentType('application/json');
    echo json_encode($response, JSON_NUMERIC_CHECK);
}

$app->run();
?>