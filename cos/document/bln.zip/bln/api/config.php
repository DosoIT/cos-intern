<?php

/**
 * Database configuration
 */
define('DB_USERNAME', 'pdbcoth');
define('DB_PASSWORD', 'init1234');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'pdbcoth_q2rr');
?>
