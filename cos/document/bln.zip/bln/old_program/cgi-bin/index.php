
<!DOCTYPE html>
<html data-ng-app="app">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">        
        <title>application</title>        
        <link rel="stylesheet" href="bootflat/css/bootstrap.min.css">        
        <link rel="stylesheet" href="bootflat/css/bootflat.min.css">        
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div ui-view></div>                                
        <script src="bootflat/js/jquery-1.10.1.min.js"></script> 
        <script src="bootflat/js/bootstrap.min.js"></script>    
        <script src="js/Application/angular1.3.js"></script>
        <script src="js/Application/angular-ui-router.min.js"></script>
        <script src="js/Application/angularJs-resource.js"></script>
        <script src="js/Application/ng-table.min.js"></script>    
        <script src="js/Application/angular-cookie.min.js"></script>
        <script src="js/Application/socket-io.js"></script> 
        <script src="js/Application/socket.min.js"></script> 
        <script src="js/Application/mScript/angularjs-app.js"></script>
        <script src="js/Application/mScript/factory.js"></script>
        <script src="js/Application/mScript/angularjs-controllers.js"></script>  
        <script src="js/Application/mScript/service.js"></script>
    </body>

</html>
