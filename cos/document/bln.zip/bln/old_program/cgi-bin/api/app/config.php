<?php

/**
 * Database configuration
 */
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '12345');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'special_p');
?>
