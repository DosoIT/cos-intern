'use strict';
var Conctrl = angular.module('Controllers', []);
Conctrl.controller('homeCtrl', ['$scope', '$state', 'Service', 'ipCookie', 'send', 'ngTableParams',
    function ($scope, $state, Service, ipCookie, send, ngTableParams) {
        $scope.list = {};
        var data = "";
        var data2 = "";
        var i = 0;
        $scope.getStd = function () {
            send.get('app/std').then(function (resf) {
                $scope.list.std = resf.data;
                data = $scope.list.std;                
            });
            setTimeout(function () {
                i++;
                $scope.getStd();
            }, 5000);
        };

        $scope.getSpecial = function () {
            send.get('app/special').then(function (resf) {
                $scope.list.special = resf.data;
                data2 = $scope.list.special;                
            });
            setTimeout(function () {
                i++;
                $scope.getSpecial();
            }, 5000);
        };

        $scope.getStd();
        $scope.getSpecial();
        $scope.registerStd = function (des) {
            if (confirm('ยืนยันการลงทะเบียน')) {
                des.checker = "true";
                console.log(des);
                send.put('app/std/' + des.id, des);
            }
        };
        $scope.registerSpecial = function (des) {
            if (confirm('ยืนยันการลงทะเบียน')) {
                des.checker = "true";
                console.log(des);
                send.put('app/special/' + des.id, des);
            }
        };
        $scope.tf = function (checkering) {
            if (angular.equals(checkering, 'false')) {
                return false;
            } else {
                return true;
            }
        };
        $scope.setPageSpecial = function () {
            $scope.tableParams2 = new ngTableParams({
                page: 1, // show first page
                count: 10           // count per page
            }, {
                total: data2.length, // length of data
                getData: function ($defer, params) {
                    $defer.resolve(data2.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });
        };
        $scope.setPageStd = function () {
            $scope.tableParams = new ngTableParams({
                page: 1, // show first page
                count: 10           // count per page
            }, {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    $defer.resolve(data.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });
        };
    }
]);
