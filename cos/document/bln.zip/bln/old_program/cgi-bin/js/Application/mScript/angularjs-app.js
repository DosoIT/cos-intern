'use strict';
var workery = angular.module('app', ['ngResource', 'Controllers', 'ipCookie', 'ui.router', 'ngTable']);
workery.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
            .state('index', {
                url: '',
                templateUrl: 'template/home.html',
                controller: 'homeCtrl'
            })
            .state('pageNotFound', {
                url: "/404",
                templateUrl: 'template/Error/404.html'
            });
    $urlRouterProvider.otherwise("/404");
});
workery.run(['$rootScope', '$sce', 'Service', function ($rootScope, $sce, MyService) {
        $rootScope.renderHtml = function (htmlCode) {//render html for show in html
            return $sce.trustAsHtml(htmlCode);
        };
    }
]);
workery.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });
                event.preventDefault();
            }
        });
    };
});



