'use strict';
var Conctrl = angular.module('Controllers', []);
Conctrl.controller('homeCtrl', ['$scope', '$state', 'Service', 'ipCookie', 'send', 'ngTableParams',
    function ($scope, $state, Service, ipCookie, send, ngTableParams) {
        $scope.list = {};
        $scope.getStd = function () {
            send.get('app/std').then(function (resf) {
                if ($scope.list.std !== resf.data) {
                    $scope.list.std = resf.data;
                }
            });
        };
        $scope.getSpecial = function () {
            send.get('app/special').then(function (resf) {
                if ($scope.list.special !== resf.data) {
                    $scope.list.special = resf.data;
                }
            });
        };
        $scope.getStd();
        $scope.getSpecial();
        $scope.registerStd = function (des) {
            if (confirm('ยืนยันการลงทะเบียน')) {
                des.checker = "true";
                des.update_at = null;
                send.put('app/std/' + des.id, des).then(function (resf) {
                    setTimeout(function () {
                        $scope.getStd();
                    }, 500);
                });
            }
        };
        $scope.registerSpecial = function (des) {
            if (confirm('ยืนยันการลงทะเบียน')) {
                des.checker = "true";
                des.update_at = null;
                send.put('app/special/' + des.id, des).then(function (resf) {
                    setTimeout(function () {
                        $scope.getSpecial();
                    }, 500);
                });
            }
        };
        $scope.evaly = function () {
            $scope.getSpecial();
            $scope.getStd();
            setTimeout(function () {
                $scope.evaly();
            }, 5000);
        };
        $scope.evaly();
        $scope.tf = function (checkering) {
            if (angular.equals(checkering, 'false')) {
                return false;
            } else {
                return true;
            }
        };
        $scope.setPageSpecial = function () {
            $scope.tableParams2 = new ngTableParams({
                page: 1, // show first page
                count: 10           // count per page
            }, {
                total: data2.length, // length of data
                getData: function ($defer, params) {
                    $defer.resolve(data2.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });
        };
        $scope.setPageStd = function () {
            $scope.tableParams = new ngTableParams({
                page: 1, // show first page
                count: 10           // count per page
            }, {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    $defer.resolve(data.slice((params.page() - 1) * params.count(), params.page() * params.count()));
                }
            });
        };
    }
]);
