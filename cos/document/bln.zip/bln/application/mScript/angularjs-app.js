'use strict';
var workery = angular.module('app', ['ngResource', 'Controllers', 'ipCookie', 'ui.router', 'angular.filter','angular-loading-bar']);
workery.config(function ($stateProvider, $urlRouterProvider, $locationProvider) {
    $urlRouterProvider.otherwise("/404.jpg");
    $stateProvider
            .state('index', {
                url: '/',
                title: 'Register App V2.0',
                header: 'Register',
                templateUrl: 'template/index.html',
                controller: 'regisCtrl'
            })
            .state('secret', {
                url: '/secret/{username}',
                title: 'Secret',
                header: 'Register',
                templateUrl: 'template/secret.html',
                controller: 'secretCtrl'
            })
            .state('pageNotFound', {
                url: "/404.jpg",
                templateUrl: 'template/404.html'
            });
    $locationProvider.html5Mode(true);
});
workery.run(['$rootScope', '$sce', 'Service', function ($rootScope, $sce, MyService) {
        $rootScope.$on('$stateChangeSuccess', function (event, current, previous) {
            $rootScope.title = current.title; //เรียกค่าจาก Controller ปัจจุบัน
            $rootScope.header = current.header;
        });
        $rootScope.renderHtml = function (htmlCode) {//render html for show in html
            return $sce.trustAsHtml(htmlCode);
        };
    }
]);
workery.directive('ngEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown keypress", function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.ngEnter);
                });
                event.preventDefault();
            }
        });
    };
});



