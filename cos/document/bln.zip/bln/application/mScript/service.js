//------------------------------------->service<------------------------------------------
Conctrl.service('Service', ['$location', '$http', '$sce', 'ipCookie', function ($location, $http, $sce, ipCookie) {//service
        var getCookie = function (cname) {
            var name = cname + "=";
            var ca = document.cookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) === ' ')
                    c = c.substring(1);
                if (c.indexOf(name) !== -1)
                    return c.substring(name.length, c.length);
            }
            return "Null";
        };
        var nl2br = function (str, is_xhtml) {
            var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
            return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
        }
        var setCookie = function (session, name) {
            var session_log_ck = session;

            var date = new Date();
            var minutes = 60;
            date.setTime(date.getTime() + (minutes * 60 * 1000));

            try {
                document.cookie = name + "=" + session_log_ck + "; expires= " + (date);
                return true;
            } catch (e) {
                return false;
            }
        };
        var removeJCookie = function (cname) {
            if ($.removeCookie(cname)) {
                return true;
            } else {
                return false;
            }
        };
        var setJCookie = function (cname, data, exp, path) {
            $.cookie(cname, data, {
                expires: exp,
                path: path
            });
        };
        var getJCookie = function (cname) {
            return $.cookie(cname);
        };
        var getip = function () {
            return 'http://202.57.163.245:4000/';
        };
        var posting = function (API, parameters) {// post data
            var baseUrl = "http://202.57.163.245:4000/";
            return $http({
                url: baseUrl + API,
                method: "POST",
                params: parameters
            }).success(function (data, status, headers, config) {
                //Do noting                 
                return data;
            }).error(function (data, status, headers, config) {
                //is Error         
//                alert('Error:' + data);
                //console.log("Error from api:" + data);
            });
        };
        var geting = function (API) {// get data
            var baseUrl = "http://202.57.163.245:4000/";
            return $http({
                url: baseUrl + API,
                method: "GET"
            }).success(function (data, status, headers, config) {
                //Do noting                                           
                return data;
            }).error(function (data, status, headers, config) {
                //is Error         
                //console.log('Error:' + data);
            });

        };
        var checkingProtocal = function () {
            var protocol = $location.protocol(); //get Protocal
            var port = $location.port(); //get port 
            if (protocol === 'https') {//check protocal
                if (port === 443) {//check port 443
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        };
        var checkingLogin = function () {
            var datas = geting('sessions/check_token?remember_token=' + ipCookie('remember_token'));
            return datas.then(function (res) {
                if (res.data.session === 'active') {
                    return true;
                } else if (res.data.session === '103') {
                    $location.path('/login');
                } else {
                    $location.path('/login');
                }
            });
        };
        var renderHtml = function (htmlCode) {//render html for show in html
            return $sce.trustAsHtml(htmlCode);
        };
        var getMonth = function (d) {
            var month = new Array();
            month[0] = "January";
            month[1] = "February";
            month[2] = "March";
            month[3] = "April";
            month[4] = "May";
            month[5] = "June";
            month[6] = "July";
            month[7] = "August";
            month[8] = "September";
            month[9] = "October";
            month[10] = "November";
            month[11] = "December";
            return month[d.getMonth()];
        };
        var getTHMonth = function (d) {
            var thmonth = new Array();
            thmonth[0] = "มกราคม";
            thmonth[1] = "กุมภาพันธ์";
            thmonth[2] = "มีนาคม";
            thmonth[3] = "เมษายน";
            thmonth[4] = "พฤษภาคม";
            thmonth[5] = "มิถุนายน";
            thmonth[6] = "กรกฎาคม";
            thmonth[7] = "สิงหาคม";
            thmonth[8] = "กันยายน";
            thmonth[9] = "ตุลาคม";
            thmonth[10] = "พฤษจิกายน";
            thmonth[11] = "ธันวาคม";
            return thmonth[d.getMonth()];
        };
        var getDate = function (d) {
            return d.getDate();
        };
        var getYear = function (d) {
            return d.getFullYear(d);
        };
        var getNowTime = function (d) {
            return d.toLocaleTimeString();
        };
        var getH = function (d) {
            return d.getHours();
        };
        var getM = function (d) {
            return d.getMinutes();
        };
        var getToDayTH = function () {
            var today = new Date();

            return getDate(today) + " " + getTHMonth(today) + " " + getYear(today);
        };
        var formatCurrency = function (val) {
            if (val == "" || val == null || val == "NULL")
                return val;

            //Split Decimals
            var arrs = val.toString().split(".");
            //Split data and reverse
            var revs = arrs[0].split("").reverse().join("");
            var len = revs.length;
            var tmp = "";
            for (i = 0; i < len; i++) {
                if (i > 0 && (i % 3) == 0) {
                    tmp += "," + revs.charAt(i);
                } else {
                    tmp += revs.charAt(i);
                }
            }

            //Split data and reverse back
            tmp = tmp.split("").reverse().join("");
            //Check Decimals
            if (arrs.length > 1 && arrs[1] != undefined) {
                tmp += "." + arrs[1];
            }
            return tmp;
        };
        return {// set namespace to function.
            getip: getip,
            removeJCookie: removeJCookie,
            setJCookie: setJCookie,
            getJCookie: getJCookie,
            formatCurrency: formatCurrency,
            getDate: getDate,
            getYear: getYear,
            getNowTime: getNowTime,
            getH: getH,
            getM: getM,
            getMonth: getMonth,
            getToDayTH: getToDayTH,
            renderHtml: renderHtml,
            getCookie: getCookie,
            posting: posting,
            geting: geting,
            setCookie: setCookie,
            checkingLogin: checkingLogin,
            checkingProtocal: checkingProtocal,
            nl2br: nl2br
        };
    }]);


