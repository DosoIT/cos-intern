'use strict';
var Conctrl = angular.module('Controllers', []);
Conctrl.controller('regisCtrl', ['$scope', '$state', 'ipCookie', 'Data', '$http',
    function ($scope, $state, ipCookie, Data, $http) {
//        angular.extend($scope,{
//            Tostr:function(str){
//                return str.toString();
//            }
//        });
        $scope.toint = parseInt;
        $scope.data = {};
        $scope.getData = function () {
            Data.get('app/list/all').then(function (resf) {
                $scope.data = resf.data;
            });
        };
        $scope.getData();
        $scope.submit = function (list, spy, spy2) {
            if (spy !== undefined && spy !== '' && spy !== null) {
                list.spy = spy.toString();
                list.status = 1;
                list.spy_regis = 1;
                if (spy2 !== undefined && spy2 !== '' && spy2 !== null) {
                    list.spy2 = spy2.toString();
                    list.spy2_regis = 1;
                    Data.put('app/update/regis/' + list.id, list).then(function (resf) {
                        console.log('registed complete');
                        $scope.getData();
                    });
                } else {
                    list.status = 1;
                    Data.put('app/update/regis/' + list.id, list).then(function (resf) {
                        console.log('registed complete');
                        $scope.getData();
                    });
                }
            } else {
                if (spy2 !== undefined && spy2 !== '' && spy2 !== null) {
                    list.status = 1;
                    list.spy2 = spy2.toString();
                    list.spy2_regis = 1;
                    Data.put('app/update/regis/' + list.id, list).then(function (resf) {
                        console.log('registed complete');
                        $scope.getData();
                    });
                } else {
                    list.status = 1;
                    Data.put('app/update/regis/' + list.id, list).then(function (resf) {
                        console.log('registed complete');
                        $scope.getData();
                    });
                }
            }
        };
    }
]);
Conctrl.controller('secretCtrl', ['$scope', '$state', 'ipCookie', 'Data', '$http', '$stateParams',
    function ($scope, $state, ipCookie, Data, $http, $stateParams) {
        if ($stateParams.username === 'pdb2015') {
                $scope.toint = parseInt;
            $scope.data = {};
            $scope.getData = function () {
                Data.get('app/list/all').then(function (resf) {
                    $scope.data = resf.data;
                });
            };
            $scope.getData();
            $scope.clearFixed = function (id) {
                if (confirm('ยืนยัน')) {
                    $scope.cls = {};
                    $scope.cls.spy = '';
                    $scope.cls.spy2 = '';
                    $scope.cls.spy2_regis = 0;
                    $scope.cls.spy_regis = 0;
                    $scope.cls.status = 0;
                    Data.put('app/update/clear/fixed/' + id, $scope.cls).then(function (resf) {
                        $scope.getData();
                    });
                }
            };
            $scope.clear = function () {
                if (confirm('ยืนยัน')) {
                    $scope.cls = {};
                    $scope.cls.spy = '';
                    $scope.cls.spy_regis = 0;
                    $scope.cls.spy2 = '';
                    $scope.cls.spy2_regis = 0;
                    $scope.cls.status = 0;
                    Data.put('app/update/clear', $scope.cls).then(function (resf) {
                        $scope.getData();
                    });
                }
            };
        } else {
            $state.go('pageNotFound');
        }
    }
]);